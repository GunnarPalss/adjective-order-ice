def count_ind_occurrence(element: str) -> dict:
    #Count index of element ocurring in the list adjectives 
    #in the list adjectives
    element = element.rstrip()
    count_to_return: dict = {'0':0, '1':0,'2':0, '3':0, '4':0, '5':0, '6':0, '7':0, '8':0}
    for line in adjectives[:-1]:
        if element in line:
            ind = line.index(element)
            if str(ind) not in count_to_return.keys():
                count_to_return[str(ind)] = 1
            else:
                count_to_return[str(ind)] += 1
  
    return count_to_return

def normalize_count(count_dict: dict) -> str:
    normalized_count:str = ''
    for key in range(len(count_dict)):
        normalized_count += str(count_dict[str(key)]) +'\t'
    return normalized_count

def append_to_total(count_dict:dict, total_count:dict):
    if not total_count:
        total_count = count_dict

    for key in range(len(count_dict)):
        total_count[str(key)] += count_dict[str(key)]
    return total_count

adjectives: list = []
with open('results/adjectives_in_a_row/adjectives_lemmas_no_duplicates_less_than_8.txt', 'r', encoding='utf-8') as in_file:
    for i in in_file:
        adjectives.append(i.split())

colors: set = set()
with open('results/categorized_adjectives/nationality.txt', 'r', encoding='utf-8') as in_file:
    for i in in_file:
        i = i.lower()
        colors.add(i)

total_count: dict = {}
with open('results/nationality_stats_in_a_row.tsv', 'w') as out_file:
    for color in colors:
        count_dict:dict = count_ind_occurrence(color)
        total_count:dict = append_to_total(count_dict, total_count)
        counts_in_order:str = normalize_count(count_dict)
        out_file.write(color.rstrip()+'\t' + counts_in_order+'\n')
    
    total_str:str = ''
    for key in range(len(total_count)):
        total_str += str(total_count[str(key)]) + '\t'
    out_file.write('Total\t' + total_str)