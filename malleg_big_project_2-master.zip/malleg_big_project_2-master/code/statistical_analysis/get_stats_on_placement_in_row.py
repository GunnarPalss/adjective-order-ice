
def get_placement_and_sentence_length(word:str, sentence:list):
    length: str = str(len(sentence))
    placement: str = str(sentence.index(word))
    return length, placement

def get_count_of_placement_for_word(word:str):
    placement_count: dict = {}
    for line in adjectives:
        if word in line:
            length, placement = get_placement_and_sentence_length(word, line)
            if length not in placement_count:
                placement_count[length] = {}
                placement_count[length][placement] = 1
            elif placement not in placement_count[length]:
                placement_count[length][placement] = 1
            else:
                placement_count[length][placement] += 1
    return placement_count
def normalize_count(placement: dict) -> str:
    normalized_count:str = ''
    
    keys_in_order:list = [int(key) for key in placement.keys()]
    keys_in_order.sort()

    for key in keys_in_order:
        normalized_count += str(placement[str(key)]) +'\t'
    return normalized_count

def append_to_total(placement_count:dict, total_count:dict):
    #Initilizing if empty
    if not total_count:
        return placement_count

    for key in placement_count.keys():
        for sub_key in placement_count[key]:
            if key not in total_count:
                total_count[key] = {}
                total_count[key][sub_key] = placement_count[key][sub_key]
            elif sub_key not in total_count[key]:
                total_count[key][sub_key] = placement_count[key][sub_key]
            else:
                total_count[key][sub_key] += placement_count[key][sub_key]
    return total_count

adjectives: list = []
with open('results/adjectives_in_a_row/adjectives_lemmas_no_duplicates_less_than_8.txt', 'r', encoding='utf-8') as in_file:
    for i in in_file:
        adjectives.append(i.split())

categorized_adjectives: set = set()
with open('results/categorized_adjectives/size.txt', 'r', encoding='utf-8') as in_file:
    for i in in_file:
        i = i.lower()
        categorized_adjectives.add(i)

total_count: dict = {}
with open('results/size_stats_on_placement_in_row.py.tsv', 'w') as out_file:
    for word in categorized_adjectives:
        word = word.rstrip()
        placement_count_of_word:dict = get_count_of_placement_for_word(word)
        total_count:dict = append_to_total(placement_count_of_word, total_count)

    keys_in_order:list = [int(key) for key in total_count.keys()]
    keys_in_order.sort()

    header = '\t1\t2\t3\t4\t5\t6\t7\t8'
    print(header)
    out_file.write(header+'\n')
    for key in keys_in_order:
        print(key,'\t',normalize_count(total_count[str(key)]))
        placement_in_order:str = normalize_count(total_count[str(key)])
        out_file.write(str(key)+'\t'+placement_in_order+'\n')