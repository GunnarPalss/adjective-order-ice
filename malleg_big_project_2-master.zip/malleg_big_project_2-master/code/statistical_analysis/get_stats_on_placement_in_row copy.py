adjectives: list = []
with open('results/adjectives_in_a_row/adjectives_lemmas_no_duplicates_less_than_8.txt', 'r', encoding='utf-8') as in_file:
    for i in in_file:
        adjectives.append(i.split())

colors: set = set()
with open('results/categorized_adjectives/colors.txt', 'r', encoding='utf-8') as in_file:
    for i in in_file:
        i = i.lower().rstrip()
        colors.add(i)

size: set = set()
with open('results/categorized_adjectives/size.txt', 'r', encoding='utf-8') as in_file:
    for i in in_file:
        i = i.lower().rstrip()
        size.add(i)

national: set = set()
with open('results/categorized_adjectives/nationality.txt', 'r', encoding='utf-8') as in_file:
    for i in in_file:
        i = i.lower().rstrip()
        national.add(i)

total_count: dict = {}
with open('results/size_stats_on_placement_in_row.py.tsv', 'w') as out_file:
    for line in adjectives:
        ordering = {}
        for word in line[:-1]:
            index_of_word = str(line.index(word))

            if word in colors: 
                ordering[index_of_word] = 'color'               

            if word in size: 
                ordering[index_of_word] = 'size'               

            if word in national: 
                ordering[index_of_word] = 'nationality'          
                 

        if len(ordering.keys()) >1:
            keys_in_order:list = [int(key) for key in ordering.keys()]
            keys_in_order.sort()

            for key in keys_in_order:
                out_file.write(ordering[str(key)]+'\t')
            out_file.write('\n')
 
"""

        word = word.rstrip()
        placement_count_of_word:dict = get_count_of_placement_for_word(word)
        total_count:dict = append_to_total(placement_count_of_word, total_count)

    keys_in_order:list = [int(key) for key in total_count.keys()]
    keys_in_order.sort()

    header = '\t1\t2\t3\t4\t5\t6\t7\t8'
    print(header)
    out_file.write(header+'\n')
    for key in keys_in_order:
        print(key,'\t',normalize_count(total_count[str(key)]))
        placement_in_order:str = normalize_count(total_count[str(key)])
        out_file.write(str(key)+'\t'+placement_in_order+'\n')"""
