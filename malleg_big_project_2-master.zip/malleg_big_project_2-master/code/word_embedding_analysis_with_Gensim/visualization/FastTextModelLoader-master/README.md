# FastText
Facebook's fasttext tech
