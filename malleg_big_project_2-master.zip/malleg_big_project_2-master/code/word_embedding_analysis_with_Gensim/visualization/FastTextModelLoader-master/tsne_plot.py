from __future__ import print_function
from gensim.models import KeyedVectors
import numpy as np
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

def plot_with_labels(low_dim_embs, labels, filename='tsne.png'):
    assert low_dim_embs.shape[0] >= len(labels), "More labels than embeddings"
    plt.figure(figsize=(18, 18))  # in inches
    for i, label in enumerate(labels):
        x, y = low_dim_embs[i, :]
        plt.scatter(x, y)
        plt.annotate(label,
                 xy=(x, y),
                 xytext=(5, 2),
                 textcoords='offset points',
                 ha='right',
                 va='bottom')

    plt.savefig(filename)

# Loading the vectors
## [Warning] Takes a lot of time 
model = KeyedVectors.load_word2vec_format(
    'code/models/igc2018_lemma_sentences_uncased_skipgram_dim300_epoch20_wngram2_minn3_maxn6.vec')

# Get list of adjectives
adjectives:list = []
with open('all_adjectives/sorted_all_adjectives_lemmas_count_4plus.txt', 'r', encoding='utf-8') as in_file:
    for line in in_file:
        adjectives.append(line)

# Limit number of tokens to be visualized
limit = 500
vector_dim = 300

# Getting tokens and vectors
words = []
embedding = np.array([])
i = 0
for word in adjectives:
    # Break the loop if limit exceeds 
    if i == limit: break
    # Appending the vectors
    try:
        embedding = np.append(embedding, model[word])

        word = word.rstrip()
        # Getting token 
        words.append(word)    
        i += 1
        print(i)
    except:
        print(f'The word {word} is not in the vocabulary')


# Reshaping the embedding vector 
embedding = embedding.reshape(limit, vector_dim)

# Creating the tsne plot [Warning: will take time]
tsne = TSNE(perplexity=30.0, n_components=2, init='pca', n_iter=5000)
low_dim_embedding = tsne.fit_transform(embedding)


with open('low_dim_embeddings.tsv', 'w') as out_file:
    for id in range(len(low_dim_embedding)):
        out_file.write(str(low_dim_embedding[id]) + '\t' + words[id].rstrip()+'\n') 

# Finally plotting and saving the fig
plot_with_labels(low_dim_embedding, words)
