from util.argparser import create_parser
from util.modules import (Timer, process_corpus)


parser = create_parser()

def main():
    #Start a timer
    timer = Timer()

    #Do the thing
    process_corpus(args)
    
    print(timer.showTimer())
    print('Finished task')

if __name__ == "__main__":
    args = parser.parse_args()
    main()
