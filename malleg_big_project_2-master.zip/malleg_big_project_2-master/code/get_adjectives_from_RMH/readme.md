Text extractor that extracts all examples of two or more adjectives accuring in a row folowed by a noun from the Icelandic Giga Corpus xml files.

To run this script please make sure you have all the necessary packages. Run the command: 

		Directory: .\code\get_adjectives_from_RMH\
		pip install –r requriments.txt

To start the extraction process make run the script extractor.py. It has three parameters 
		--data1, -d1: Which is the directory to the Icelandic Giga corpus. The script crawls every subfolder of this directory and creates a list with directory to individual xml fil

		-n_iobs, -n: Integer with the number of parallel processes. Recommended is n = number of cores minus one.

The command should look something like this:

		python .\code\get_adjectives_from_RMH\corpus_processor.py -d1 .\data\rmh2\  -n 3
