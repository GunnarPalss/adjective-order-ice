import argparse


def create_parser():
    parser = argparse.ArgumentParser('Need update',
        add_help=True,
        formatter_class=argparse.MetavarTypeHelpFormatter)

    parser.add_argument(
        '-i', '--input', required=False, type=str, help='path to data folder to extract')
    
    parser.add_argument(
        '-n', '--n_jobs', required=False, type= int, default=3, help='Count of how many parallel jobs')

    return parser