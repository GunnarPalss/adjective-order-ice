import os
import time
from xml.etree import ElementTree as ET
from concurrent.futures import ProcessPoolExecutor
from tqdm import tqdm
import json

class Timer():
    '''
    Timer class for exicution time results.
    '''
    def __init__(self):
        self.startTime = time.time()
    
    def showTimer(self):
        runtime = round((time.time()-self.startTime)/60, 2)
        return(f'\nRuntime: {runtime} min\n')

def create_directory():
    '''
    If the data directory is not present, create it!
    An error will occer if the data dir is only partially present.
    '''
    if not os.path.exists('./results/'):
        os.makedirs('./results/')

def get_file_directories(directory):
    '''
    Takes in a folder directory and creates a list of all 
    directories within that folder.
    '''
    print(f'Getting list of files form {directory} and its subfolders')
    filepath_list: list = []
    for dirName, _subdirList, fileList in os.walk(directory, topdown=False):
        for fname in fileList:
            filepath_list.append(dirName + '/' + fname)  
        
    print(f'Done, found {len(filepath_list)} files')
    return filepath_list

def read_file(path: str): 
    NS = {'a': 'http://www.tei-c.org/ns/1.0'}
    root = ET.parse(path).getroot()
    
    list_of_two_or_more_adjectives_followed_by_a_noun: list = []
    tmp_storages: list = []
    ignore_words: list = [',', 'og']
    for seg in root.findall('.//a:s', NS): 
        for node in seg.getchildren():            
            if tmp_storages != 0 and node.attrib['type'][0] not in ['l','n']:
                if node.text not in ignore_words:
                    tmp_storages = []
                    continue
            if node.attrib['type'][0] == 'l':
                tmp_storages.append((node.text, node.attrib['lemma'], node.attrib['type']))
                #tmp_line.append(node.attrib['lemma'])

            if node.attrib['type'][0] == 'n' and len(tmp_storages) != 0:
                tmp_storages.append((node.text, node.attrib['lemma'], node.attrib['type']))
                #tmp_line.append(node.attrib['lemma'])
                
                if len(tmp_storages) > 2:
                    list_of_two_or_more_adjectives_followed_by_a_noun.append(tmp_storages)          
                tmp_storages = []
    return list_of_two_or_more_adjectives_followed_by_a_noun

def find_all_adjective_lemmas(path:str):
    NS = {'a': 'http://www.tei-c.org/ns/1.0'}
    root = ET.parse(path).getroot()

    all_adjective_lemmas: list = []
    for seg in root.findall('.//a:s', NS): 
        for node in seg.getchildren():
            if node.attrib['type'][0] == 'l':            
                all_adjective_lemmas.append(node.attrib['lemma'])
    return all_adjective_lemmas

def process_corpus(args):
    create_directory()
    paths: list = get_file_directories(args.input)
    filename = './results/adjectives_in_a_row/'+'all_adjectives_lemmas.txt'
    results: list = []
    with open(filename, 'w+', encoding='utf-8') as f_out:
        with ProcessPoolExecutor(max_workers=args.n_jobs) as executor:
            results =  tqdm(executor.map(
                read_file,
                paths,
                chunksize=75), 
                total=len(paths),
                unit=' files')
            for chunk in results:
                for line in chunk:
                    if type(line) == list:
                        for nodes in line:
                            f_out.write('\t'.join(nodes))
                            f_out.write('\t')
                        f_out.write('\n')
                    else:
                        f_out.write(line+'\n')

